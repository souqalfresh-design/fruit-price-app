import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  collection, 
  query, 
  onSnapshot, 
  doc, 
  setDoc, 
  writeBatch, 
  getDoc,
  getDocs,
  deleteDoc,
  Timestamp,
  orderBy
} from 'firebase/firestore';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  User,
  signOut
} from 'firebase/auth';
import { db, auth } from './firebase';
import * as XLSX from 'xlsx';
import Fuse from 'fuse.js';
import { useDropzone } from 'react-dropzone';
import { 
  Search, 
  Mic, 
  MicOff, 
  Upload, 
  LogOut, 
  ChevronRight, 
  AlertCircle,
  CheckCircle2,
  Loader2,
  Package,
  Scale,
  History,
  Camera,
  Image as ImageIcon,
  ZoomIn,
  ZoomOut,
  Maximize,
  RotateCcw,
  Trash2,
  Edit2,
  Eye,
  EyeOff,
  Pin,
  PinOff,
  TrendingUp,
  TrendingDown,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";

// --- Utility ---
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Types ---
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

interface Product {
  id: string;
  name: string;
  pricePerKg?: number;
  pricePerBox?: number;
  previousPricePerKg?: number;
  previousPricePerBox?: number;
  updatedAt: any;
  isPinned?: boolean;
  manualPinColor?: 'green' | 'red';
}

interface Metadata {
  lastUploadDate: any;
  uploadedBy: string;
  sourceType?: 'image' | 'excel';
  sourceData?: string;
}

// --- Components ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [metadata, setMetadata] = useState<Metadata | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);
  const [showSource, setShowSource] = useState(false);
  const [isFullScreenSource, setIsFullScreenSource] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [isDeleting, setIsDeleting] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<{ type: 'success' | 'error' | 'loading', message: string } | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editForm, setEditForm] = useState<{ name: string, pricePerKg: string, pricePerBox: string }>({ name: '', pricePerKg: '', pricePerBox: '' });
  const [editPassword, setEditPassword] = useState('');
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false);
  const [isSavingEdit, setIsSavingEdit] = useState(false);
  const [isScreenHidden, setIsScreenHidden] = useState(false);
  const [unhidePassword, setUnhidePassword] = useState('');
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [deletePassword, setDeletePassword] = useState('');
  const [showDeletePrompt, setShowDeletePrompt] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallBanner, setShowInstallBanner] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [quickAddForm, setQuickAddForm] = useState({ name: '', pricePerKg: '', pricePerBox: '' });
  const [isSavingQuickAdd, setIsSavingQuickAdd] = useState(false);

  const adminEmail = "souqalfresh@gmail.com";
  const EDIT_PASSWORD = process.env.VITE_EDIT_PASSWORD;
  const HIDE_PASSWORD = process.env.VITE_HIDE_PASSWORD || "abu123";
  const DELETE_PASSWORD = "saood321";

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      // Only show banner if not already in standalone mode
      if (!window.matchMedia('(display-mode: standalone)').matches) {
        setShowInstallBanner(true);
      }
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
      setShowInstallBanner(false);
    }
  };

  const handleEditClick = (product: Product) => {
    setEditingProduct(product);
    setEditForm({
      name: product.name,
      pricePerKg: product.pricePerKg?.toString() || '',
      pricePerBox: product.pricePerBox?.toString() || '',
    });
    setEditPassword('');
    setShowPasswordPrompt(true);
  };

  const handleTogglePin = async (product: Product) => {
    try {
      const productRef = doc(db, 'products', product.id);
      await setDoc(productRef, { isPinned: !product.isPinned }, { merge: true });
    } catch (error) {
      console.error("Error toggling pin:", error);
      handleFirestoreError(error, OperationType.UPDATE, `products/${product.id}`);
    }
  };

  const handleSetPinColor = async (product: Product, color: 'green' | 'red' | null) => {
    try {
      const productRef = doc(db, 'products', product.id);
      await setDoc(productRef, { manualPinColor: color }, { merge: true });
    } catch (error) {
      console.error("Error setting pin color:", error);
      handleFirestoreError(error, OperationType.UPDATE, `products/${product.id}`);
    }
  };

  const handleQuickAdd = async () => {
    if (!quickAddForm.name) return;
    
    setIsSavingQuickAdd(true);
    try {
      const item = {
        name: quickAddForm.name,
        pricePerKg: quickAddForm.pricePerKg === '' ? null : parseFloat(quickAddForm.pricePerKg),
        pricePerBox: quickAddForm.pricePerBox === '' ? null : parseFloat(quickAddForm.pricePerBox),
      };
      
      await processProducts([item]);
      
      setQuickAddForm({ name: '', pricePerKg: '', pricePerBox: '' });
      setShowQuickAdd(false);
      setUploadStatus({ type: 'success', message: 'Product added successfully!' });
      setTimeout(() => setUploadStatus(null), 3000);
    } catch (error) {
      console.error(error);
      setUploadStatus({ type: 'error', message: 'Failed to add product.' });
    } finally {
      setIsSavingQuickAdd(false);
    }
  };
  const handleSaveEdit = async () => {
    if (editPassword !== EDIT_PASSWORD) {
      alert("Incorrect password!");
      return;
    }

    if (!editingProduct) return;

    setIsSavingEdit(true);
    try {
      const productRef = doc(db, 'products', editingProduct.id);
      const newPriceKg = editForm.pricePerKg === '' ? null : parseFloat(editForm.pricePerKg);
      const newPriceBox = editForm.pricePerBox === '' ? null : parseFloat(editForm.pricePerBox);

      const updatedData: any = {
        name: editForm.name,
        pricePerKg: newPriceKg,
        pricePerBox: newPriceBox,
        updatedAt: Timestamp.now()
      };

      // Track changes
      if (newPriceKg !== null && editingProduct.pricePerKg !== newPriceKg) {
        updatedData.previousPricePerKg = editingProduct.pricePerKg;
      }
      if (newPriceBox !== null && editingProduct.pricePerBox !== newPriceBox) {
        updatedData.previousPricePerBox = editingProduct.pricePerBox;
      }

      await setDoc(productRef, updatedData, { merge: true });
      
      setEditPassword('');
      setEditingProduct(null);
      setShowPasswordPrompt(false);
      setUploadStatus({ type: 'success', message: 'Product updated successfully!' });
      setTimeout(() => setUploadStatus(null), 3000);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `products/${editingProduct.id}`);
    } finally {
      setIsSavingEdit(false);
    }
  };

  const handleUnhide = () => {
    if (unhidePassword === HIDE_PASSWORD) {
      setIsScreenHidden(false);
      setUnhidePassword('');
    } else {
      alert("Incorrect password!");
    }
  };

  const handleDeleteClick = (product: Product) => {
    setProductToDelete(product);
    setShowDeletePrompt(true);
    setDeletePassword('');
  };

  const handleConfirmDelete = async () => {
    if (deletePassword !== DELETE_PASSWORD) {
      alert("Incorrect delete password!");
      return;
    }

    if (!productToDelete) return;
    setIsDeleting(true);

    try {
      await deleteDoc(doc(db, 'products', productToDelete.id));
      setShowDeletePrompt(false);
      setProductToDelete(null);
      setDeletePassword('');
      setUploadStatus({ type: 'success', message: 'Product deleted successfully!' });
      setTimeout(() => setUploadStatus(null), 3000);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `products/${productToDelete.id}`);
    } finally {
      setIsDeleting(false);
    }
  };

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setIsAdmin(u?.email === adminEmail);
      setIsAuthReady(true);
    });
    return unsubscribe;
  }, []);

  // Data Listener
  useEffect(() => {
    if (!user) return;

    const q = query(collection(db, 'products'), orderBy('name', 'asc'));
    const unsubscribeProducts = onSnapshot(q, (snapshot) => {
      const p = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product));
      setProducts(p);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'products');
    });

    const unsubscribeMeta = onSnapshot(doc(db, 'metadata', 'lastUpload'), (doc) => {
      if (doc.exists()) {
        setMetadata(doc.data() as Metadata);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'metadata/lastUpload');
    });

    return () => {
      unsubscribeProducts();
      unsubscribeMeta();
    };
  }, [user]);

  // Fuzzy Search
  const fuse = useMemo(() => {
    return new Fuse(products, {
      keys: ['name'],
      threshold: 0.4,
      distance: 100,
    });
  }, [products]);

  const filteredProducts = useMemo(() => {
    if (!searchQuery) return products;
    return fuse.search(searchQuery).map(result => result.item);
  }, [searchQuery, products, fuse]);

  const priceAlerts = useMemo(() => {
    return products.filter(p => {
      const kgChange = p.previousPricePerKg && p.pricePerKg ? Math.abs((p.pricePerKg - p.previousPricePerKg) / p.previousPricePerKg) : 0;
      const boxChange = p.previousPricePerBox && p.pricePerBox ? Math.abs((p.pricePerBox - p.previousPricePerBox) / p.previousPricePerBox) : 0;
      return kgChange > 0.05 || boxChange > 0.05; // 5% change for "sudden" alert
    }).sort((a, b) => (b.updatedAt?.seconds || 0) - (a.updatedAt?.seconds || 0)).slice(0, 5);
  }, [products]);

  // Voice Search
  const startListening = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      // Clean up transcript (e.g., "price of mango" -> "mango")
      const query = transcript.toLowerCase()
        .replace(/price of /g, '')
        .replace(/ price/g, '')
        .replace(/box /g, '')
        .trim();
      setSearchQuery(query);
    };

    recognition.start();
  };

  // Excel Upload
  const processProducts = async (items: any[], source?: { type: 'image' | 'excel', data: string }, preFetchedMap?: Map<string, any>) => {
    const batch = writeBatch(db);
    const now = Timestamp.now();

    let currentProductsMap = preFetchedMap;
    
    if (!currentProductsMap) {
      // Fetch current products to track changes if not provided
      const currentProductsSnap = await getDocs(collection(db, 'products'));
      currentProductsMap = new Map<string, any>();
      currentProductsSnap.docs.forEach(doc => {
        currentProductsMap?.set(doc.id, doc.data());
      });
    }

    items.forEach((item) => {
      const name = item.name || item['Item Name'] || item['item'] || item['Name'];
      if (!name) return;

      const trimmedName = String(name).trim();
      const docId = trimmedName.toLowerCase().replace(/[^a-z0-9]/g, '_');

      const priceKg = parseFloat(item.pricePerKg || item['Price per KG'] || item['price_kg'] || item['KG']);
      const priceBox = parseFloat(item.pricePerBox || item['Price per BOX'] || item['price_box'] || item['BOX']);
      
      const newPriceKg = isNaN(priceKg) ? null : priceKg;
      const newPriceBox = isNaN(priceBox) ? null : priceBox;

      const existingProduct = currentProductsMap?.get(docId);
      
      const productRef = doc(db, 'products', docId);
      const updateData: any = {
        name: trimmedName,
        pricePerKg: newPriceKg,
        pricePerBox: newPriceBox,
        updatedAt: now
      };

      // Track changes if price actually changed
      if (existingProduct) {
        if (newPriceKg !== null && existingProduct.pricePerKg !== newPriceKg) {
          updateData.previousPricePerKg = existingProduct.pricePerKg;
        }
        if (newPriceBox !== null && existingProduct.pricePerBox !== newPriceBox) {
          updateData.previousPricePerBox = existingProduct.pricePerBox;
        }
      }

      batch.set(productRef, updateData, { merge: true });
    });

    // Update metadata
    const metaRef = doc(db, 'metadata', 'lastUpload');
    batch.set(metaRef, {
      lastUploadDate: now,
      uploadedBy: user?.email || 'unknown',
      sourceType: source?.type,
      sourceData: source?.data
    });

    try {
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'batch/products');
    }
  };

  const handleDeduplicate = async () => {
    setUploadStatus({ type: 'loading', message: 'Searching for duplicates...' });
    try {
      let productsSnap;
      try {
        productsSnap = await getDocs(collection(db, 'products'));
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'products');
        return;
      }
      
      const seen = new Map<string, string>(); // name -> docId
      const toDelete: string[] = [];

      // Sort by updatedAt descending if possible, but for now just keep the first one found
      productsSnap.docs.forEach((doc) => {
        const data = doc.data();
        const nameKey = String(data.name || '').toLowerCase().trim();
        if (!nameKey) return;

        if (seen.has(nameKey)) {
          toDelete.push(doc.id);
        } else {
          seen.set(nameKey, doc.id);
        }
      });

      if (toDelete.length === 0) {
        setUploadStatus({ type: 'success', message: 'No duplicates found!' });
        setTimeout(() => setUploadStatus(null), 3000);
        return;
      }

      const batch = writeBatch(db);
      toDelete.forEach(id => {
        batch.delete(doc(db, 'products', id));
      });
      
      try {
        await batch.commit();
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, 'batch/deduplicate');
      }

      setUploadStatus({ type: 'success', message: `Successfully removed ${toDelete.length} duplicates.` });
      setTimeout(() => setUploadStatus(null), 3000);
    } catch (error) {
      console.error(error);
      setUploadStatus({ type: 'error', message: 'Failed to remove duplicates.' });
    }
  };

  const handleDeleteAll = async () => {
    if (!window.confirm("Are you sure you want to delete ALL price data? This cannot be undone.")) {
      return;
    }

    setIsDeleting(true);
    setUploadStatus({ type: 'loading', message: 'Deleting all data...' });

    try {
      const batch = writeBatch(db);
      
      // Delete all products
      let productsSnap;
      try {
        productsSnap = await getDocs(collection(db, 'products'));
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'products');
        return;
      }
      
      productsSnap.forEach((doc) => {
        batch.delete(doc.ref);
      });

      // Delete metadata
      const metaRef = doc(db, 'metadata', 'lastUpload');
      batch.delete(metaRef);

      try {
        await batch.commit();
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, 'batch/deleteAll');
      }
      
      setUploadStatus({ type: 'success', message: 'All data has been cleared.' });
      setTimeout(() => setUploadStatus(null), 3000);
    } catch (error) {
      console.error(error);
      setUploadStatus({ type: 'error', message: 'Failed to delete data.' });
    } finally {
      setIsDeleting(false);
    }
  };

  const onDrop = async (acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return;

    setUploadStatus({ 
      type: 'loading', 
      message: acceptedFiles.length > 1 
        ? `Processing ${acceptedFiles.length} files...` 
        : 'AI is reading your list...' 
    });

    try {
      let processedCount = 0;
      
      // Pre-fetch products once for all files
      const currentProductsSnap = await getDocs(collection(db, 'products'));
      const productsMap = new Map<string, any>();
      currentProductsSnap.docs.forEach(doc => {
        productsMap.set(doc.id, doc.data());
      });

      // Process files in parallel for speed
      await Promise.all(acceptedFiles.map(async (file) => {
        try {
          if (file.type.includes('spreadsheet') || file.name.endsWith('.xlsx')) {
            const data = await file.arrayBuffer();
            const workbook = XLSX.read(data);
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const jsonData = XLSX.utils.sheet_to_json(worksheet) as any[];
            await processProducts(jsonData, { type: 'excel', data: JSON.stringify(jsonData.slice(0, 50)) }, productsMap);
          } else if (file.type.startsWith('image/')) {
            await processImage(file, productsMap);
          }
          processedCount++;
          if (acceptedFiles.length > 1) {
            setUploadStatus({ type: 'loading', message: `Processed ${processedCount}/${acceptedFiles.length} files...` });
          }
        } catch (err) {
          console.error(`Error processing ${file.name}:`, err);
        }
      }));

      setUploadStatus({ 
        type: 'success', 
        message: acceptedFiles.length > 1 
          ? `Successfully processed ${processedCount} files!` 
          : 'Price list updated successfully!' 
      });
      setTimeout(() => setUploadStatus(null), 3000);
    } catch (error) {
      console.error(error);
      setUploadStatus({ type: 'error', message: 'Failed to upload files.' });
    }
  };

  const processImage = async (file: File, productsMap?: Map<string, any>) => {
    try {
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve) => {
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(file);
      });
      const base64Data = await base64Promise;

      // Optimize: Resize image to a smaller size for faster AI processing
      const compressImage = (base64: string, maxWidth = 800): Promise<string> => {
        return new Promise((resolve) => {
          const img = new Image();
          img.onload = () => {
            const canvas = document.createElement('canvas');
            const scale = Math.min(1, maxWidth / img.width);
            canvas.width = img.width * scale;
            canvas.height = img.height * scale;
            const ctx = canvas.getContext('2d');
            ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
            // Use lower quality for faster upload/processing
            resolve(canvas.toDataURL('image/jpeg', 0.5));
          };
          img.src = `data:${file.type};base64,${base64}`;
        });
      };
      
      const compressedDataUrl = await compressImage(base64Data);
      const compressedBase64 = compressedDataUrl.split(',')[1];

      const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
      const model = "gemini-3-flash-preview";
      
      const response = await genAI.models.generateContent({
        model,
        contents: [
          {
            parts: [
              { text: "Extract fruits/veg names and prices (KG/BOX) from this image. Return JSON array: [{name, pricePerKg, pricePerBox}]. Use null if price is missing. Be fast." },
              { inlineData: { mimeType: 'image/jpeg', data: compressedBase64 } }
            ]
          }
        ],
        config: {
          responseMimeType: "application/json",
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                pricePerKg: { type: Type.NUMBER },
                pricePerBox: { type: Type.NUMBER }
              },
              required: ["name"]
            }
          }
        }
      });

      const extractedData = JSON.parse(response.text || '[]');
      if (extractedData.length > 0) {
        await processProducts(extractedData, { type: 'image', data: compressedDataUrl }, productsMap);
      }
    } catch (error) {
      console.error("AI Error:", error);
      throw error;
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop, 
    accept: { 
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'image/*': ['.jpeg', '.jpg', '.png']
    },
    multiple: true
  });

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error(error);
    }
  };

  if (!isAuthReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-stone-50">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-stone-50 p-6 text-center">
        <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mb-6">
          <Package className="w-10 h-10 text-emerald-600" />
        </div>
        <h1 className="text-3xl font-bold text-stone-900 mb-2">Abu Saood</h1>
        <p className="text-stone-500 mb-8 max-w-xs">Internal Price Checker for Staff Only</p>
        <button 
          onClick={handleLogin}
          className="w-full max-w-xs bg-emerald-600 text-white py-4 rounded-2xl font-semibold shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all active:scale-95"
        >
          Sign in with Google
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen font-sans text-stone-900 pb-20">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-stone-200 sticky top-0 z-50 px-4 py-3">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 fruit-gradient rounded-xl flex items-center justify-center shadow-lg shadow-emerald-900/20">
              <Package className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-black text-lg leading-none tracking-tight">Abu Saood</h1>
              <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">Fruits & Veg</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setIsScreenHidden(true)}
              className="p-2.5 text-stone-400 hover:bg-stone-100 rounded-xl transition-all active:scale-90"
              title="Hide Screen"
            >
              <EyeOff className="w-5 h-5" />
            </button>
            {isAdmin && (
              <button 
                onClick={() => setShowAdmin(!showAdmin)}
                className={cn(
                  "p-2.5 rounded-xl transition-all active:scale-90",
                  showAdmin ? "bg-emerald-600 text-white shadow-lg shadow-emerald-200" : "text-stone-400 hover:bg-stone-100"
                )}
              >
                <Upload className="w-5 h-5" />
              </button>
            )}
            <button 
              onClick={() => signOut(auth)}
              className="p-2.5 text-stone-400 hover:bg-stone-100 rounded-xl transition-colors"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="relative h-48 overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&q=80&w=1000" 
          alt="Fresh Fruits" 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#fdfcf8] via-transparent to-black/20" />
        <div className="absolute bottom-6 left-6 right-6 flex flex-col items-center gap-4">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/90 backdrop-blur-sm px-6 py-3 rounded-[2rem] border border-white shadow-2xl text-center"
          >
            <span className="text-[10px] uppercase tracking-[0.2em] font-black text-emerald-600 block mb-0.5">Today's Market Prices</span>
            <span className="text-xl font-black text-stone-900">
              {new Date().toLocaleDateString('en-AE', { 
                weekday: 'long', 
                day: 'numeric', 
                month: 'long'
              })}
            </span>
          </motion.div>

          <motion.button
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            onClick={() => {
              setSearchQuery('');
              setShowSource(true);
            }}
            className="bg-emerald-600/90 backdrop-blur-sm text-white px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-900/20 active:scale-95 transition-all flex items-center gap-2 border border-emerald-500/50"
          >
            <ImageIcon className="w-3.5 h-3.5" />
            View Original Source
          </motion.button>
        </div>
      </div>

      <main className="max-w-md mx-auto p-6 -mt-4 relative z-10">
        {/* Admin Panel */}
        <AnimatePresence>
          {showAdmin && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden mb-6"
            >
              <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm">
                <h2 className="font-bold mb-4 flex items-center gap-2">
                  <Upload className="w-4 h-4 text-emerald-600" />
                  Upload Daily Price List
                </h2>
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div 
                    {...getRootProps()} 
                    className={cn(
                      "border-2 border-dashed rounded-xl p-4 text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-2",
                      isDragActive ? "border-emerald-500 bg-emerald-50" : "border-stone-200 hover:border-emerald-400"
                    )}
                  >
                    <input {...getInputProps()} />
                    <Upload className="w-6 h-6 text-stone-300" />
                    <span className="text-xs font-medium text-stone-500">Excel File</span>
                  </div>

                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-stone-200 border-dashed rounded-xl p-4 text-center hover:border-emerald-400 transition-all flex flex-col items-center justify-center gap-2"
                  >
                    <Camera className="w-6 h-6 text-stone-300" />
                    <span className="text-xs font-medium text-stone-500">Take Photo</span>
                    <input 
                      type="file" 
                      accept="image/*" 
                      capture="environment" 
                      multiple
                      className="hidden" 
                      ref={fileInputRef}
                      onChange={(e) => {
                        const files = e.target.files;
                        if (files && files.length > 0) onDrop(Array.from(files));
                      }}
                    />
                  </button>
                </div>

                <div className="bg-stone-50 rounded-xl p-4 text-center border border-stone-100">
                  <p className="text-xs text-stone-400">
                    Upload an Excel file or take a clear photo of your handwritten or printed price list.
                  </p>
                </div>

                <div className="mt-4 pt-4 border-t border-stone-100 space-y-2">
                  <button 
                    onClick={() => setShowQuickAdd(!showQuickAdd)}
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black uppercase tracking-widest text-emerald-700 bg-emerald-100 hover:bg-emerald-200 transition-all active:scale-95"
                  >
                    <Package className="w-3.5 h-3.5" />
                    {showQuickAdd ? 'Close Quick Add' : 'Quick Add Product'}
                  </button>

                  <AnimatePresence>
                    {showQuickAdd && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="bg-white border border-stone-200 rounded-2xl p-4 space-y-3 mt-2">
                          <input 
                            type="text"
                            placeholder="Item Name (e.g. Mango)"
                            value={quickAddForm.name}
                            onChange={(e) => setQuickAddForm({...quickAddForm, name: e.target.value})}
                            className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-emerald-500"
                          />
                          <div className="grid grid-cols-2 gap-2">
                            <input 
                              type="number"
                              placeholder="Price/KG"
                              value={quickAddForm.pricePerKg}
                              onChange={(e) => setQuickAddForm({...quickAddForm, pricePerKg: e.target.value})}
                              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-emerald-500"
                            />
                            <input 
                              type="number"
                              placeholder="Price/BOX"
                              value={quickAddForm.pricePerBox}
                              onChange={(e) => setQuickAddForm({...quickAddForm, pricePerBox: e.target.value})}
                              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-emerald-500"
                            />
                          </div>
                          <button 
                            onClick={handleQuickAdd}
                            disabled={isSavingQuickAdd || !quickAddForm.name}
                            className="w-full py-2 bg-emerald-600 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-emerald-700 transition-all disabled:opacity-50"
                          >
                            {isSavingQuickAdd ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'Save Product'}
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <button 
                    onClick={handleDeduplicate}
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black uppercase tracking-widest text-emerald-600 bg-emerald-50 hover:bg-emerald-100 transition-all active:scale-95"
                  >
                    <History className="w-3.5 h-3.5" />
                    Remove Duplicate Entries
                  </button>
                  <button 
                    onClick={handleDeleteAll}
                    disabled={isDeleting}
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black uppercase tracking-widest text-red-500 bg-red-50 hover:bg-red-100 transition-all active:scale-95 disabled:opacity-50"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Delete All Price Data
                  </button>
                </div>

                {uploadStatus && (
                  <div className={cn(
                    "mt-4 p-3 rounded-xl flex items-center gap-3 text-sm border",
                    uploadStatus.type === 'success' ? "bg-emerald-50 text-emerald-700 border-emerald-100" : 
                    uploadStatus.type === 'error' ? "bg-red-50 text-red-700 border-red-100" : "bg-stone-50 text-stone-700 border-stone-200"
                  )}>
                    {uploadStatus.type === 'success' && <CheckCircle2 className="w-4 h-4" />}
                    {uploadStatus.type === 'error' && <AlertCircle className="w-4 h-4" />}
                    {uploadStatus.type === 'loading' && <Loader2 className="w-4 h-4 animate-spin" />}
                    <div className="flex-1">
                      <p className="font-bold">{uploadStatus.message}</p>
                      {uploadStatus.type === 'success' && (
                        <button 
                          onClick={() => {
                            setSearchQuery('');
                            setShowAdmin(false);
                          }}
                          className="text-[10px] uppercase tracking-widest font-black underline mt-1"
                        >
                          View Full List
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      {/* PWA Install Banner */}
      <AnimatePresence>
        {showInstallBanner && (
          <motion.div 
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="fixed bottom-24 left-4 right-4 z-[60] xl:left-auto xl:right-4 xl:w-80"
          >
            <div className="bg-white rounded-3xl p-4 border border-emerald-100 shadow-2xl flex items-center gap-4">
              <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center flex-shrink-0">
                <Package className="w-6 h-6 text-emerald-600" />
              </div>
              <div className="flex-1">
                <h4 className="text-sm font-black text-stone-900">Install App</h4>
                <p className="text-[10px] font-bold text-stone-400 uppercase tracking-wider">Add to Home Screen</p>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => setShowInstallBanner(false)}
                  className="p-2 text-stone-400 hover:text-stone-600"
                >
                  <X className="w-4 h-4" />
                </button>
                <button 
                  onClick={handleInstallClick}
                  className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-emerald-700 transition-all"
                >
                  Install
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Side Alerts (Pinned Items) - Desktop Split */}
      {/* Left Side: Price Down (Green) */}
      <div className="fixed top-24 left-4 z-40 hidden xl:flex flex-col gap-4 w-72 max-h-[80vh] overflow-y-auto no-scrollbar pointer-events-none">
        <AnimatePresence>
          {products.filter(p => p.isPinned).filter(p => {
            const isPriceUp = (p.pricePerKg || 0) > (p.previousPricePerKg || p.pricePerKg || 0) ||
                             (p.pricePerBox || 0) > (p.previousPricePerBox || p.pricePerBox || 0);
            const alertColor = p.manualPinColor || (isPriceUp ? 'red' : 'green');
            return alertColor === 'green';
          }).map(product => {
            const hasPriceChange = (product.previousPricePerKg && product.previousPricePerKg !== product.pricePerKg) || 
                                 (product.previousPricePerBox && product.previousPricePerBox !== product.pricePerBox);
            const isPriceUp = (product.pricePerKg || 0) > (product.previousPricePerKg || product.pricePerKg || 0) ||
                             (product.pricePerBox || 0) > (product.previousPricePerBox || product.pricePerBox || 0);
            const alertColor = 'green';
            
            return (
              <motion.div
                key={`side-pinned-left-${product.id}`}
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                className="pointer-events-auto rounded-3xl p-4 border card-shadow relative overflow-hidden bg-emerald-50 border-emerald-100 animate-notice"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-black text-stone-900 truncate pr-2">{product.name}</span>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => handleSetPinColor(product, 'red')}
                      className="w-10 h-6 rounded-full p-1 transition-colors relative pointer-events-auto bg-emerald-200"
                    >
                      <motion.div 
                        animate={{ x: 0 }}
                        className="w-4 h-4 rounded-full flex items-center justify-center shadow-sm bg-emerald-600"
                      >
                        <TrendingDown className="w-2.5 h-2.5 text-white" />
                      </motion.div>
                    </button>
                    <button 
                      onClick={() => handleTogglePin(product)}
                      className="text-stone-400 hover:text-stone-600 p-1 pointer-events-auto"
                    >
                      <PinOff className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-1.5">
                    <TrendingDown className="w-5 h-5 text-emerald-600" />
                    <div className="flex flex-col">
                      {product.pricePerKg && (
                        <span className="text-xl font-black leading-tight text-emerald-600">
                          {product.pricePerKg}
                          <span className="text-[10px] ml-1 opacity-60">AED/kg</span>
                        </span>
                      )}
                      {product.pricePerBox && (
                        <span className="text-sm font-bold opacity-80 leading-tight text-emerald-500">
                          {product.pricePerBox}
                          <span className="text-[10px] ml-1">AED/box</span>
                        </span>
                      )}
                    </div>
                  </div>
                  {hasPriceChange && (
                    <div className={cn(
                      "text-[10px] font-bold flex items-center gap-0.5 mt-1",
                      isPriceUp ? "text-red-500" : "text-emerald-600"
                    )}>
                      {isPriceUp ? <AlertCircle className="w-3 h-3" /> : <CheckCircle2 className="w-3 h-3" />}
                      {isPriceUp ? 'HIKE' : 'DROP'}
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Right Side: Price Hike (Red) */}
      <div className="fixed top-24 right-4 z-40 hidden xl:flex flex-col gap-4 w-72 max-h-[80vh] overflow-y-auto no-scrollbar pointer-events-none">
        <AnimatePresence>
          {products.filter(p => p.isPinned).filter(p => {
            const isPriceUp = (p.pricePerKg || 0) > (p.previousPricePerKg || p.pricePerKg || 0) ||
                             (p.pricePerBox || 0) > (p.previousPricePerBox || p.pricePerBox || 0);
            const alertColor = p.manualPinColor || (isPriceUp ? 'red' : 'green');
            return alertColor === 'red';
          }).map(product => {
            const hasPriceChange = (product.previousPricePerKg && product.previousPricePerKg !== product.pricePerKg) || 
                                 (product.previousPricePerBox && product.previousPricePerBox !== product.pricePerBox);
            const isPriceUp = (product.pricePerKg || 0) > (product.previousPricePerKg || product.pricePerKg || 0) ||
                             (product.pricePerBox || 0) > (product.previousPricePerBox || product.pricePerBox || 0);
            const alertColor = 'red';
            
            return (
              <motion.div
                key={`side-pinned-right-${product.id}`}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 50 }}
                className="pointer-events-auto rounded-3xl p-4 border card-shadow relative overflow-hidden bg-red-50 border-red-100 animate-notice-red"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-black text-stone-900 truncate pr-2">{product.name}</span>
                  <div className="flex items-center gap-2">
                    {/* Toggle Switch */}
                    <button 
                      onClick={() => handleSetPinColor(product, 'green')}
                      className="w-10 h-6 rounded-full p-1 transition-colors relative pointer-events-auto bg-red-200"
                    >
                      <motion.div 
                        animate={{ x: 16 }}
                        className="w-4 h-4 rounded-full flex items-center justify-center shadow-sm bg-red-600"
                      >
                        <TrendingUp className="w-2.5 h-2.5 text-white" />
                      </motion.div>
                    </button>
                    <button 
                      onClick={() => handleTogglePin(product)}
                      className="text-stone-400 hover:text-stone-600 p-1 pointer-events-auto"
                    >
                      <PinOff className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-1.5">
                    <TrendingUp className="w-5 h-5 text-red-600" />
                    <div className="flex flex-col">
                      {product.pricePerKg && (
                        <span className="text-xl font-black leading-tight text-red-600">
                          {product.pricePerKg}
                          <span className="text-[10px] ml-1 opacity-60">AED/kg</span>
                        </span>
                      )}
                      {product.pricePerBox && (
                        <span className="text-sm font-bold opacity-80 leading-tight text-red-500">
                          {product.pricePerBox}
                          <span className="text-[10px] ml-1">AED/box</span>
                        </span>
                      )}
                    </div>
                  </div>
                  {hasPriceChange && (
                    <div className={cn(
                      "text-[10px] font-bold flex items-center gap-0.5 mt-1",
                      isPriceUp ? "text-red-500" : "text-emerald-600"
                    )}>
                      {isPriceUp ? <AlertCircle className="w-3 h-3" /> : <CheckCircle2 className="w-3 h-3" />}
                      {isPriceUp ? 'HIKE' : 'DROP'}
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Mobile Pinned Alerts (Horizontal scroll at top) */}
      <div className="xl:hidden mb-6">
        {products.some(p => p.isPinned) && (
          <div className="space-y-3">
            <div className="flex items-center justify-between px-2">
              <h2 className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em]">Pinned Alerts</h2>
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            </div>
            <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar">
              {[...products.filter(p => p.isPinned)].sort((a, b) => {
                const getCol = (p: any) => {
                  const isUp = (p.pricePerKg || 0) > (p.previousPricePerKg || p.pricePerKg || 0) ||
                               (p.pricePerBox || 0) > (p.previousPricePerBox || p.pricePerBox || 0);
                  return p.manualPinColor || (isUp ? 'red' : 'green');
                };
                const colA = getCol(a);
                const colB = getCol(b);
                if (colA === 'green' && colB === 'red') return -1;
                if (colA === 'red' && colB === 'green') return 1;
                return 0;
              }).map(product => {
                const hasPriceChange = (product.previousPricePerKg && product.previousPricePerKg !== product.pricePerKg) || 
                                     (product.previousPricePerBox && product.previousPricePerBox !== product.pricePerBox);
                const isPriceUp = (product.pricePerKg || 0) > (product.previousPricePerKg || product.pricePerKg || 0) ||
                                 (product.pricePerBox || 0) > (product.previousPricePerBox || product.pricePerBox || 0);
                
                const alertColor = product.manualPinColor || (isPriceUp ? 'red' : 'green');

                return (
                  <motion.div
                    key={`mobile-pinned-${product.id}`}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className={cn(
                      "flex-shrink-0 w-64 rounded-3xl p-4 border card-shadow relative overflow-hidden",
                      alertColor === 'red' ? "bg-red-50 border-red-100 animate-notice-red" : "bg-emerald-50 border-emerald-100 animate-notice"
                    )}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-black text-stone-900 truncate pr-2">{product.name}</span>
                      <div className="flex items-center gap-3">
                        {/* Toggle Switch */}
                        <button 
                          onClick={() => handleSetPinColor(product, alertColor === 'red' ? 'green' : 'red')}
                          className={cn(
                            "w-10 h-6 rounded-full p-1 transition-colors relative",
                            alertColor === 'red' ? "bg-red-200" : "bg-emerald-200"
                          )}
                        >
                          <motion.div 
                            animate={{ x: alertColor === 'red' ? 16 : 0 }}
                            transition={{ type: "spring", stiffness: 500, damping: 30 }}
                            className={cn(
                              "w-4 h-4 rounded-full flex items-center justify-center shadow-sm",
                              alertColor === 'red' ? "bg-red-600" : "bg-emerald-600"
                            )}
                          >
                            {alertColor === 'red' ? <TrendingUp className="w-2.5 h-2.5 text-white" /> : <TrendingDown className="w-2.5 h-2.5 text-white" />}
                          </motion.div>
                        </button>
                        <button 
                          onClick={() => handleTogglePin(product)}
                          className="text-stone-400 hover:text-stone-600"
                        >
                          <PinOff className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1.5">
                        {alertColor === 'green' ? (
                          <TrendingDown className="w-5 h-5 text-emerald-600" />
                        ) : (
                          <TrendingUp className="w-5 h-5 text-red-600" />
                        )}
                        <div className="flex flex-col">
                          {product.pricePerKg && (
                            <span className={cn(
                              "text-xl font-black leading-tight",
                              alertColor === 'red' ? "text-red-600" : "text-emerald-600"
                            )}>
                              {product.pricePerKg}
                              <span className="text-[10px] ml-1 opacity-60">AED/kg</span>
                            </span>
                          )}
                          {product.pricePerBox && (
                            <span className={cn(
                              "text-sm font-bold opacity-80 leading-tight",
                              alertColor === 'red' ? "text-red-500" : "text-emerald-500"
                            )}>
                              {product.pricePerBox}
                              <span className="text-[10px] ml-1">AED/box</span>
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}
      </div>

        {/* Search Bar */}
        <div className="sticky top-[65px] z-20 pt-2 pb-6">
          <div className="flex gap-2">
            <div className="relative group flex-1">
              <div className="absolute inset-y-0 left-5 flex items-center pointer-events-none">
                <Search className="w-5 h-5 text-stone-400 group-focus-within:text-emerald-500 transition-colors" />
              </div>
              <input 
                type="text"
                placeholder="Search fruit or vegetable..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white border border-stone-200 rounded-3xl pl-14 pr-16 py-5 card-shadow focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-lg font-medium"
              />
              <button 
                onClick={startListening}
                className={cn(
                  "absolute inset-y-2.5 right-2.5 w-12 flex items-center justify-center rounded-2xl transition-all",
                  isListening ? "bg-red-500 text-white animate-pulse shadow-lg shadow-red-200" : "bg-stone-100 text-stone-500 hover:bg-stone-200"
                )}
              >
                {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>
            </div>
            {isAdmin && (
              <button 
                onClick={() => setShowQuickAdd(!showQuickAdd)}
                className={cn(
                  "w-16 h-16 rounded-3xl flex items-center justify-center transition-all card-shadow",
                  showQuickAdd ? "bg-emerald-600 text-white" : "bg-white text-emerald-600 border border-stone-100"
                )}
                title="Quick Add Product"
              >
                <Package className="w-6 h-6" />
              </button>
            )}
          </div>
          
          <AnimatePresence>
            {showQuickAdd && (
              <motion.div 
                initial={{ height: 0, opacity: 0, y: -10 }}
                animate={{ height: 'auto', opacity: 1, y: 0 }}
                exit={{ height: 0, opacity: 0, y: -10 }}
                className="overflow-hidden"
              >
                <div className="bg-white border border-stone-200 rounded-[2rem] p-6 space-y-4 mt-4 card-shadow">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-black text-stone-900 uppercase tracking-widest">Quick Add Product</h3>
                    <button onClick={() => setShowQuickAdd(false)} className="text-stone-400 hover:text-stone-600">
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  </div>
                  <input 
                    type="text"
                    placeholder="Item Name (e.g. Mango)"
                    value={quickAddForm.name}
                    onChange={(e) => setQuickAddForm({...quickAddForm, name: e.target.value})}
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-5 py-3 text-base focus:outline-none focus:border-emerald-500 transition-all"
                  />
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest ml-2">Price/KG</label>
                      <input 
                        type="number"
                        placeholder="0.00"
                        value={quickAddForm.pricePerKg}
                        onChange={(e) => setQuickAddForm({...quickAddForm, pricePerKg: e.target.value})}
                        className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-5 py-3 text-base focus:outline-none focus:border-emerald-500 transition-all"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest ml-2">Price/BOX</label>
                      <input 
                        type="number"
                        placeholder="0.00"
                        value={quickAddForm.pricePerBox}
                        onChange={(e) => setQuickAddForm({...quickAddForm, pricePerBox: e.target.value})}
                        className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-5 py-3 text-base focus:outline-none focus:border-emerald-500 transition-all"
                      />
                    </div>
                  </div>
                  <button 
                    onClick={handleQuickAdd}
                    disabled={isSavingQuickAdd || !quickAddForm.name}
                    className="w-full py-4 bg-emerald-600 text-white rounded-2xl text-sm font-black uppercase tracking-widest hover:bg-emerald-700 transition-all active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isSavingQuickAdd ? <Loader2 className="w-5 h-5 animate-spin" /> : (
                      <>
                        <CheckCircle2 className="w-5 h-5" />
                        Save & Update Alerts
                      </>
                    )}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          
          {metadata && (
            <div className="mt-4 flex items-center justify-between px-2">
              <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider font-black text-stone-400">
                <History className="w-3.5 h-3.5" />
                Updated: {metadata.lastUploadDate?.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
              <button 
                onClick={() => setSearchQuery('')}
                className="text-[10px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-50 px-3 py-1 rounded-full hover:bg-emerald-100 transition-colors active:scale-95"
              >
                {products.length} Items • Show All
              </button>
            </div>
          )}
        </div>

        {/* Price Alerts Section */}
        {!searchQuery && priceAlerts.length > 0 && (
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              <h2 className="text-xs font-black text-stone-400 uppercase tracking-[0.2em]">Sudden Price Changes</h2>
            </div>
            <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar -mx-6 px-6">
              {priceAlerts.map((product) => {
                const kgDiff = product.pricePerKg && product.previousPricePerKg ? product.pricePerKg - product.previousPricePerKg : 0;
                const boxDiff = product.pricePerBox && product.previousPricePerBox ? product.pricePerBox - product.previousPricePerBox : 0;
                const isKgUp = kgDiff > 0;
                const isBoxUp = boxDiff > 0;

                return (
                  <motion.div 
                    key={`alert-${product.id}`}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex-shrink-0 w-64 bg-white rounded-3xl border border-red-100 p-4 shadow-lg shadow-red-900/5 relative overflow-hidden group"
                  >
                    <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
                      <AlertCircle className="w-12 h-12 text-red-500" />
                    </div>
                    
                    <h3 className="font-black text-stone-900 mb-3 truncate pr-8">{product.name}</h3>
                    
                    <div className="space-y-2">
                      {kgDiff !== 0 && (
                        <div className="flex items-center justify-between bg-stone-50 rounded-xl p-2">
                          <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">Per KG</span>
                          <div className={cn(
                            "flex items-center gap-1 font-black text-xs",
                            isKgUp ? "text-red-500" : "text-emerald-500"
                          )}>
                            {isKgUp ? '↑' : '↓'} {Math.abs(kgDiff).toFixed(2)}
                            <span className="text-[8px] opacity-50 ml-0.5">AED</span>
                          </div>
                        </div>
                      )}
                      {boxDiff !== 0 && (
                        <div className="flex items-center justify-between bg-stone-50 rounded-xl p-2">
                          <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">Per BOX</span>
                          <div className={cn(
                            "flex items-center gap-1 font-black text-xs",
                            isBoxUp ? "text-red-500" : "text-emerald-500"
                          )}>
                            {isBoxUp ? '↑' : '↓'} {Math.abs(boxDiff).toFixed(2)}
                            <span className="text-[8px] opacity-50 ml-0.5">AED</span>
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <button 
                      onClick={() => setSearchQuery(product.name)}
                      className="w-full mt-3 py-2 bg-red-50 text-red-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-100 transition-colors"
                    >
                      View Details
                    </button>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}

        {/* Results */}
        <div className="space-y-5">
          {filteredProducts.length > 0 ? (
            filteredProducts.map((product) => (
              <motion.div 
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                key={product.id}
                className="bg-white rounded-[2.5rem] border border-stone-100 p-6 card-shadow hover:scale-[1.02] transition-all duration-300 group"
              >
                <div className="flex justify-between items-start mb-5">
                  <div>
                    <h3 className="text-2xl font-black text-stone-900 leading-tight group-hover:text-emerald-700 transition-colors">{product.name}</h3>
                    <div className="flex items-center gap-1 mt-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">Fresh Stock</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button 
                      onClick={() => handleTogglePin(product)}
                      className={cn(
                        "p-2.5 rounded-xl transition-all active:scale-90",
                        product.isPinned ? "text-emerald-600 bg-emerald-50" : "text-stone-400 hover:bg-stone-50"
                      )}
                      title={product.isPinned ? "Unpin from top" : "Pin to top"}
                    >
                      {product.isPinned ? <PinOff className="w-5 h-5" /> : <Pin className="w-5 h-5" />}
                    </button>
                    <button 
                      onClick={() => handleEditClick(product)}
                      className="p-2.5 text-stone-400 hover:bg-emerald-50 hover:text-emerald-600 rounded-xl transition-all active:scale-90"
                      title="Edit Product"
                    >
                      <Edit2 className="w-5 h-5" />
                    </button>
                    <button 
                      onClick={() => handleDeleteClick(product)}
                      className="p-2.5 text-stone-400 hover:bg-red-50 hover:text-red-600 rounded-xl transition-all active:scale-90"
                      title="Delete Product"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                    <div className="w-10 h-10 bg-stone-50 rounded-2xl flex items-center justify-center text-stone-300 group-hover:bg-emerald-50 group-hover:text-emerald-400 transition-colors">
                      <ChevronRight className="w-6 h-6" />
                    </div>
                  </div>
                </div>
                
                <div className={cn(
                  "grid gap-4",
                  (typeof product.pricePerKg === 'number' && typeof product.pricePerBox === 'number') ? "grid-cols-2" : "grid-cols-1"
                )}>
                  {typeof product.pricePerKg === 'number' && (
                    <div className="bg-emerald-50/50 rounded-3xl p-4 border border-emerald-100/50 relative overflow-hidden group-hover:bg-emerald-50 transition-colors">
                      <div className="absolute -right-2 -bottom-2 opacity-5 group-hover:opacity-10 transition-opacity">
                        <Scale className="w-16 h-16 text-emerald-900" />
                      </div>
                      <div className="flex items-center gap-1.5 text-[10px] font-black text-emerald-600 uppercase tracking-[0.15em] mb-1.5">
                        <Scale className="w-3.5 h-3.5" />
                        Per KG
                      </div>
                      <div className="text-3xl font-black text-emerald-900 flex items-baseline gap-1">
                        {product.pricePerKg}
                        <span className="text-xs font-bold opacity-40">AED</span>
                      </div>
                      {product.previousPricePerKg && product.previousPricePerKg !== product.pricePerKg && (
                        <div className={cn(
                          "mt-1 text-[10px] font-bold flex items-center gap-1",
                          product.pricePerKg > product.previousPricePerKg ? "text-red-500" : "text-emerald-600"
                        )}>
                          {product.pricePerKg > product.previousPricePerKg ? '↑' : '↓'}
                          {Math.abs(product.pricePerKg - product.previousPricePerKg).toFixed(2)}
                          <span className="opacity-50">from {product.previousPricePerKg}</span>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {typeof product.pricePerBox === 'number' && (
                    <div className="bg-orange-50/50 rounded-3xl p-4 border border-orange-100/50 relative overflow-hidden group-hover:bg-orange-50 transition-colors">
                      <div className="absolute -right-2 -bottom-2 opacity-5 group-hover:opacity-10 transition-opacity">
                        <Package className="w-16 h-16 text-orange-900" />
                      </div>
                      <div className="flex items-center gap-1.5 text-[10px] font-black text-orange-600 uppercase tracking-[0.15em] mb-1.5">
                        <Package className="w-3.5 h-3.5" />
                        Per BOX
                      </div>
                      <div className="text-3xl font-black text-orange-900 flex items-baseline gap-1">
                        {product.pricePerBox}
                        <span className="text-xs font-bold opacity-40">AED</span>
                      </div>
                      {product.previousPricePerBox && product.previousPricePerBox !== product.pricePerBox && (
                        <div className={cn(
                          "mt-1 text-[10px] font-bold flex items-center gap-1",
                          product.pricePerBox > product.previousPricePerBox ? "text-red-500" : "text-orange-600"
                        )}>
                          {product.pricePerBox > product.previousPricePerBox ? '↑' : '↓'}
                          {Math.abs(product.pricePerBox - product.previousPricePerBox).toFixed(2)}
                          <span className="opacity-50">from {product.previousPricePerBox}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            ))
          ) : (
            <div className="text-center py-20">
              <div className="w-20 h-20 bg-stone-100 rounded-[2rem] flex items-center justify-center mx-auto mb-6">
                <Search className="w-10 h-10 text-stone-300" />
              </div>
              <p className="text-stone-400 font-bold text-lg">No fresh items found</p>
              <p className="text-stone-300 text-sm mt-1 mb-6">Try searching for something else</p>
              <button 
                onClick={() => setSearchQuery('')}
                className="bg-stone-100 text-stone-600 px-6 py-3 rounded-2xl font-bold text-sm hover:bg-stone-200 transition-all active:scale-95"
              >
                Show Full Price List
              </button>
            </div>
          )}
        </div>
      </main>

      {/* Quick Action Button (Mobile) */}
      <div className="fixed bottom-8 right-8 z-40">
        <button 
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="w-16 h-16 fruit-gradient text-white rounded-2xl shadow-2xl shadow-emerald-900/40 flex items-center justify-center active:scale-90 transition-all hover:rotate-6"
        >
          <Search className="w-7 h-7" />
        </button>
      </div>

      {/* Hide Overlay */}
      <AnimatePresence>
        {isScreenHidden && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-stone-900 flex flex-col items-center justify-center p-6 text-center"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="w-full max-w-md"
            >
              <div className="w-24 h-24 bg-emerald-500/10 rounded-[2.5rem] flex items-center justify-center mx-auto mb-8">
                <Eye className="w-12 h-12 text-emerald-500" />
              </div>
              <h2 className="text-3xl font-black text-white mb-2">Screen Hidden</h2>
              <p className="text-stone-400 font-bold mb-12">Enter password to resume</p>
              
              <div className="space-y-4">
                <input 
                  type="password"
                  placeholder="Password"
                  value={unhidePassword}
                  onChange={(e) => setUnhidePassword(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleUnhide()}
                  autoComplete="off"
                  className="w-full bg-white/5 border border-white/10 rounded-3xl px-6 py-5 focus:outline-none focus:ring-4 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all text-center text-xl font-black text-white placeholder:text-stone-600"
                />
                <button 
                  onClick={handleUnhide}
                  className="w-full py-5 rounded-3xl font-black text-white bg-emerald-600 shadow-2xl shadow-emerald-900/40 hover:bg-emerald-700 transition-all active:scale-95 text-lg"
                >
                  Unhide Screen
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delete Modal */}
      <AnimatePresence>
        {showDeletePrompt && productToDelete && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setShowDeletePrompt(false);
                setProductToDelete(null);
              }}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-sm rounded-[2.5rem] overflow-hidden shadow-2xl p-8"
            >
              <div className="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center mb-6">
                <Trash2 className="w-8 h-8 text-red-500" />
              </div>
              <h2 className="text-2xl font-black text-stone-900 mb-2">Delete Product?</h2>
              <p className="text-stone-500 font-bold mb-6">Are you sure you want to delete <span className="text-red-500">"{productToDelete.name}"</span>?</p>
              
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-black text-red-500 uppercase tracking-widest block mb-2">Delete Password Required</label>
                  <input 
                    type="password"
                    placeholder="Enter password to delete"
                    value={deletePassword}
                    onChange={(e) => setDeletePassword(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleConfirmDelete()}
                    autoComplete="off"
                    className="w-full bg-red-50/50 border border-red-100 rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all font-bold text-red-900"
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <button 
                    onClick={() => {
                      setShowDeletePrompt(false);
                      setProductToDelete(null);
                    }}
                    className="flex-1 py-4 rounded-2xl font-bold text-stone-500 bg-stone-100 hover:bg-stone-200 transition-all active:scale-95"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleConfirmDelete}
                    disabled={isDeleting || !deletePassword}
                    className="flex-1 py-4 rounded-2xl font-bold text-white bg-red-600 shadow-lg shadow-red-200 hover:bg-red-700 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Delete'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Modal */}
      <AnimatePresence>
        {showPasswordPrompt && editingProduct && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setShowPasswordPrompt(false);
                setEditingProduct(null);
              }}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-sm rounded-[2.5rem] overflow-hidden shadow-2xl p-8"
            >
              <h2 className="text-2xl font-black text-stone-900 mb-6">Edit Product</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest block mb-2">Item Name</label>
                  <input 
                    type="text"
                    value={editForm.name}
                    onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                    className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-bold"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest block mb-2">Price / KG</label>
                    <input 
                      type="number"
                      value={editForm.pricePerKg}
                      onChange={(e) => setEditForm({...editForm, pricePerKg: e.target.value})}
                      placeholder="0.00"
                      className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-stone-400 uppercase tracking-widest block mb-2">Price / BOX</label>
                    <input 
                      type="number"
                      value={editForm.pricePerBox}
                      onChange={(e) => setEditForm({...editForm, pricePerBox: e.target.value})}
                      placeholder="0.00"
                      className="w-full bg-stone-50 border border-stone-200 rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-bold"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-stone-100 mt-4">
                  <label className="text-[10px] font-black text-red-500 uppercase tracking-widest block mb-2">Admin Password Required</label>
                  <input 
                    type="password"
                    placeholder="Enter password to save"
                    value={editPassword}
                    onChange={(e) => setEditPassword(e.target.value)}
                    autoComplete="off"
                    className="w-full bg-red-50/50 border border-red-100 rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all font-bold text-red-900"
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <button 
                    onClick={() => {
                      setShowPasswordPrompt(false);
                      setEditingProduct(null);
                    }}
                    className="flex-1 py-4 rounded-2xl font-bold text-stone-500 bg-stone-100 hover:bg-stone-200 transition-all active:scale-95"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleSaveEdit}
                    disabled={isSavingEdit || !editPassword}
                    className="flex-1 py-4 rounded-2xl font-bold text-white bg-emerald-600 shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isSavingEdit ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save Changes'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Source Modal */}
      <AnimatePresence>
        {showSource && metadata && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSource(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ 
                opacity: 1, 
                scale: 1, 
                y: 0,
                maxWidth: isFullScreenSource ? '100vw' : '32rem', // max-w-lg is 32rem
                height: isFullScreenSource ? '100vh' : 'auto',
                maxHeight: isFullScreenSource ? '100vh' : '80vh',
                borderRadius: isFullScreenSource ? '0px' : '2.5rem'
              }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className={cn(
                "relative bg-white w-full overflow-hidden shadow-2xl flex flex-col transition-all duration-300",
                isFullScreenSource ? "fixed inset-0 z-[120]" : ""
              )}
            >
              <div className="p-6 border-b border-stone-100 flex items-center justify-between bg-stone-50/50">
                <div>
                  <h2 className="text-xl font-black text-stone-900">Original Source</h2>
                  <p className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">
                    Uploaded by {metadata.uploadedBy}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {metadata.sourceType === 'image' && (
                    <div className="flex items-center bg-white rounded-2xl p-1 shadow-sm border border-stone-100 mr-2">
                      <button 
                        onClick={() => setZoom(prev => Math.max(0.5, prev - 0.25))}
                        className="p-2 text-stone-400 hover:text-stone-900 transition-colors"
                        title="Zoom Out"
                      >
                        <ZoomOut className="w-4 h-4" />
                      </button>
                      <span className="text-[10px] font-black text-stone-400 w-10 text-center">
                        {Math.round(zoom * 100)}%
                      </span>
                      <button 
                        onClick={() => setZoom(prev => Math.min(3, prev + 0.25))}
                        className="p-2 text-stone-400 hover:text-stone-900 transition-colors"
                        title="Zoom In"
                      >
                        <ZoomIn className="w-4 h-4" />
                      </button>
                      <div className="w-px h-4 bg-stone-100 mx-1" />
                      <button 
                        onClick={() => setIsFullScreenSource(!isFullScreenSource)}
                        className={cn(
                          "p-2 transition-colors rounded-lg",
                          isFullScreenSource ? "bg-emerald-50 text-emerald-600" : "text-stone-400 hover:text-stone-900"
                        )}
                        title={isFullScreenSource ? "Exit Full Screen" : "Full Screen"}
                      >
                        <Maximize className="w-4 h-4" />
                      </button>
                      <div className="w-px h-4 bg-stone-100 mx-1" />
                      <button 
                        onClick={() => setZoom(1)}
                        className="p-2 text-stone-400 hover:text-stone-900 transition-colors"
                        title="Reset Zoom"
                      >
                        <RotateCcw className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                  <button 
                    onClick={() => {
                      setShowSource(false);
                      setIsFullScreenSource(false);
                      setZoom(1);
                    }}
                    className="w-10 h-10 bg-white rounded-2xl flex items-center justify-center text-stone-400 hover:text-stone-900 transition-colors shadow-sm border border-stone-100"
                  >
                    <LogOut className="w-5 h-5 rotate-180" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-auto p-6 bg-stone-100/30">
                {!metadata.sourceType ? (
                  <div className="text-center py-12">
                    <AlertCircle className="w-12 h-12 text-stone-200 mx-auto mb-4" />
                    <p className="text-stone-400 font-bold">No source file available for this update.</p>
                  </div>
                ) : metadata.sourceType === 'image' ? (
                  <div className="flex justify-center min-h-full">
                    <div 
                      className="transition-transform duration-200 ease-out origin-top"
                      style={{ transform: `scale(${zoom})` }}
                    >
                      <img 
                        src={metadata.sourceData} 
                        alt="Original Price List" 
                        className="max-w-full h-auto rounded-xl shadow-lg border border-white"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 text-emerald-600 mb-4">
                      <Package className="w-5 h-5" />
                      <span className="font-black uppercase tracking-widest text-xs">Excel Data Preview</span>
                    </div>
                    <div className="border border-stone-200 rounded-2xl overflow-hidden">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-stone-50 border-b border-stone-200">
                          <tr>
                            <th className="px-4 py-3 font-black text-stone-400 uppercase tracking-widest">Item</th>
                            <th className="px-4 py-3 font-black text-stone-400 uppercase tracking-widest text-right">KG</th>
                            <th className="px-4 py-3 font-black text-stone-400 uppercase tracking-widest text-right">BOX</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-stone-100">
                          {JSON.parse(metadata.sourceData || '[]').map((row: any, i: number) => (
                            <tr key={i} className="hover:bg-stone-50/50 transition-colors">
                              <td className="px-4 py-3 font-bold text-stone-700">{row.name || row['Item Name'] || row['item']}</td>
                              <td className="px-4 py-3 text-right font-mono text-emerald-600">{row.pricePerKg || row['Price per KG'] || '—'}</td>
                              <td className="px-4 py-3 text-right font-mono text-orange-600">{row.pricePerBox || row['Price per BOX'] || '—'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>

              <div className="p-6 bg-stone-50/50 border-t border-stone-100">
                <button 
                  onClick={() => {
                    setShowSource(false);
                    setIsFullScreenSource(false);
                    setZoom(1);
                  }}
                  className="w-full bg-stone-900 text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-lg shadow-stone-200 active:scale-95 transition-all"
                >
                  Close Preview
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
